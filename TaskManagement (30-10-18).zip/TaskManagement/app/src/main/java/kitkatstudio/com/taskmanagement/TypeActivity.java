package kitkatstudio.com.taskmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class TypeActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private RadioButton radiobutton;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int selectedId = radioGroup.getCheckedRadioButtonId();

                radiobutton = (RadioButton) findViewById(selectedId);

                String value= radiobutton.getText().toString();

                if(value.equals("Employee"))
                {
                    Intent intent = new Intent(TypeActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        });


    }
}
