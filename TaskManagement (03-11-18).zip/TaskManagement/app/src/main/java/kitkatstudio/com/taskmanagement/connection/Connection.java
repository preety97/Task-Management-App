package kitkatstudio.com.taskmanagement.connection;

public class Connection {

//    public static final String API = " http://androidproject.in/security_app/apis/";
//
//    public static final String IMAGE_API = " http://androidproject.in/security_app/";

    public static final String API = "http://daemonvision.com/o7demoservers/task/apis/";

    public static final String IMAGE_API = "http://daemonvision.com/o7demoservers/task/";

}
